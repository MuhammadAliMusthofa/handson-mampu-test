(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0o.x~8u._.css","static/chunks/node_modules_0td1wm~._.js","static/chunks/src_providers_QueryProvider_tsx_0pr2k.y._.js"],
    source: "dynamic"
});
