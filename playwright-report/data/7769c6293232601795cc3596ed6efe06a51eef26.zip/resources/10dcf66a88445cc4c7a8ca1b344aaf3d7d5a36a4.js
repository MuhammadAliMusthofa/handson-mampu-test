(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0asnx-o._.js","static/chunks/node_modules_03fzjt5._.js"],
    source: "dynamic"
});
